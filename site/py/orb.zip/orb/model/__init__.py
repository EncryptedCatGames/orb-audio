"""Browser bundle: only the numpy-only spec tokenizer."""
